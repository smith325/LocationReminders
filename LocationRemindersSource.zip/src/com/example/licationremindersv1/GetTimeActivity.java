package com.example.licationremindersv1;

import android.app.Activity;

public class GetTimeActivity extends Activity {
	

}
